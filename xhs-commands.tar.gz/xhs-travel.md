# 小红书文旅关键词搜索 → 可视化网页

通过 CDP Proxy 直连用户 Chrome 浏览器，搜索小红书指定关键词，逐个点击卡片采集完整帖子内容+评论，生成可视化 HTML 页面并发布到 GitHub Pages。

## 用法

```
/xhs-travel 关键词1,关键词2 [--slug 页面文件名] [--title 页面标题]
```

## 参数

- `$ARGUMENTS` 中第一个参数为逗号分隔的搜索关键词（必填）
- `--slug`：HTML 文件名（不含 .html），默认取关键词拼音，如 `yigong-bagai`
- `--title`：页面大标题，默认为关键词本身

## 示例

```
/xhs-travel 易贡乡,八盖乡 --slug yigong-bagai --title 藏东秘境：易贡乡&八盖乡
/xhs-travel 成都私人地陪
/xhs-travel 大理民宿,大理旅拍 --slug dali-travel
```

## 执行步骤

### 1. 解析参数

从 `$ARGUMENTS` 中提取：
- `keywords`：逗号分隔的关键词字符串
- `slug`：页面文件名（无则自动生成）
- `title`：页面标题（无则用关键词）

### 2. 检查 CDP Proxy

```bash
curl -s http://localhost:3456/health
```

必须返回 `connected: true`。如果未运行：
```bash
node ~/.claude/skills/web-access/scripts/check-deps.mjs
```

### 3. 逐个关键词采集

对每个关键词执行以下流程：

#### 3a. 打开搜索页

```bash
TARGET=$(curl -s "http://localhost:3456/new?url=$(python3 -c "import urllib.parse; print(urllib.parse.quote('https://www.xiaohongshu.com/search_result?keyword=关键词&source=web_search_result_notes', safe=''))")" | python3 -c "import sys,json; print(json.load(sys.stdin)['targetId'])")
```
等待 3 秒。

#### 3b. 获取卡片数

```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d 'document.querySelectorAll("section.note-item").length'
```

#### 3c. 逐个点击卡片采集详情+评论

对每个卡片 i（从 0 到 卡片数-1）：

**点击卡片：**
```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d "document.querySelectorAll('section.note-item')[$i]?.querySelector('a.cover')?.click(); 'ok'"
```
等待 2.5 秒。

**提取笔记详情：**
```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d '
var nid = location.pathname.match(/\/(explore|search_result)\/([a-z0-9]+)/)?.[2] || "";
var tEl = document.querySelector("#detail-title") || document.querySelector("[class*=\"detail\"] .title") || document.querySelector(".title");
var dEl = document.querySelector("#detail-desc") || document.querySelector("[class*=\"detail\"] .desc") || document.querySelector(".desc");
var aLink = document.querySelector("[class*=\"author\"] a[href*=\"/user/profile/\"]");
var aName = document.querySelector("[class*=\"author\"] .username, [class*=\"author\"] [class*=\"name\"]");
var avEl = document.querySelector("[class*=\"author\"] img, img[class*=\"avatar\"]");
var covEl = document.querySelector("[class*=\"slide\"] img, .note-image img");
JSON.stringify({
  note_id: nid, title: tEl?.textContent?.trim() || "",
  content: (dEl?.textContent?.trim() || "").slice(0, 2000),
  type: document.querySelector("video") ? "video" : "normal",
  author_id: aLink?.href?.match(/\/user\/profile\/([a-z0-9]+)/)?.[1] || "",
  author_name: (aName?.textContent?.trim() || "").replace(/\d{4}-\d{2}-\d{2}$/, "").trim(),
  author_avatar: avEl?.src || "",
  liked_count: parseInt([...document.querySelectorAll("[class*=\"like\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  collected_count: parseInt([...document.querySelectorAll("[class*=\"collect\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  comment_count: parseInt([...document.querySelectorAll("[class*=\"chat\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  share_count: parseInt([...document.querySelectorAll("[class*=\"share\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  note_url: location.href, cover_url: covEl?.src || "",
  source: "cdp_browser", keyword: "关键词"
})
'
```

**提取评论：**
```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d '
var noteId = location.pathname.match(/\/(explore|search_result)\/([a-z0-9]+)/)?.[2] || "";
var items = document.querySelectorAll(".comment-item");
var comments = [];
items.forEach(function(el) {
  var id = el.id?.replace("comment-", "") || "";
  var userLink = el.querySelector("a[href*='"'"'/user/profile/'"'"']");
  var userId = userLink?.getAttribute("data-user-id") || "";
  var nameEl = el.querySelector(".name");
  var avatarEl = el.querySelector(".avatar-item");
  var contentEl = el.querySelector(".note-text");
  var likeEl = el.querySelector("[class*='"'"'like'"'"'] [class*='"'"'count'"'"']");
  if (!contentEl) return;
  comments.push({
    note_id: noteId, comment_id: id, user_id: userId,
    nickname: nameEl?.textContent?.trim() || "",
    avatar: avatarEl?.src || "",
    content: contentEl?.textContent?.trim()?.slice(0, 500) || "",
    liked_count: parseInt(likeEl?.textContent) || 0,
    sub_comment_count: 0
  });
});
JSON.stringify(comments)
'
```

**返回搜索页：**
```bash
curl -s "http://localhost:3456/back?target=$TARGET"
```
等待 1.2 秒，继续下一个卡片。

#### 3d. 关闭搜索页 tab

```bash
curl -s "http://localhost:3456/close?target=$TARGET"
```

### 4. 提交数据到服务器

```bash
curl -s -X POST -H "X-API-Key: dazi2026" -H "Content-Type: application/json" \
  -d '{"notes": [...], "keyword": "关键词"}' \
  "http://113.44.65.151:3721/api/collect/notes"

curl -s -X POST -H "X-API-Key: dazi2026" -H "Content-Type: application/json" \
  -d '{"comments": [...]}' \
  "http://113.44.65.151:3721/api/collect/comments"
```

### 5. 生成 HTML 页面

调用服务器导出接口：
```bash
curl -s -X POST -H "X-API-Key: dazi2026" -H "Content-Type: application/json" \
  -d '{"keyword":"关键词","title":"页面标题"}' \
  "http://113.44.65.151:3721/api/export/html"
```

保存到 `/Users/wenpi/seomachine/shaihe-site/pages/{slug}.html`。

HTML 模板结构（单文件，内嵌 CSS + JS + JSON 数据）：

**头部**：渐变背景 `linear-gradient(135deg, #667eea, #764ba2)`，标题、采集日期、统计数据
**功能**：搜索框（实时过滤）、图文/视频筛选按钮
**卡片列表**：排名、标题（可点击跳转原文）、类型标签、作者、正文（可展开）、互动数据、评论
**底部**：数据来源声明

### 6. 提交并推送到 GitHub

```bash
cd /Users/wenpi/seomachine/shaihe-site
git add pages/{slug}.html
git commit -m "Add XHS travel notes page: {title}"
git pull --rebase origin main
git push origin main
```

### 7. 输出访问 URL

```
https://wenpi.github.io/shaihe-office/pages/{slug}.html
```

## 依赖

- CDP Proxy（web-access skill 提供，`localhost:3456`）
- Chrome 远程调试已开启，用户已登录小红书
- 搭子工具服务器（`113.44.65.151:3721`）
- shaihe-office GitHub 仓库（GitHub Pages 已开启）

## 注意事项

- CDP 直连用户 Chrome，天然带登录态，无需 Cookie/签名，零风控风险
- HTML 为纯静态单文件，无外部依赖，可离线查看
- 仅供学习研究，遵守小红书使用条款
