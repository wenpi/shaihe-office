# 小红书 CDP 采集 → 可视化网页

通过 CDP Proxy 直连用户 Chrome 浏览器，在小红书搜索页逐个点击卡片打开详情 overlay，采集完整帖子内容（标题、正文、互动数据）+ 评论（用户、内容、头像），生成可视化 HTML 页面。

## 用法

```
/xhs-overlay 关键词1,关键词2 [--slug 文件名] [--title 页面标题]
```

## 参数

- `$ARGUMENTS` 中第一个参数为逗号分隔的搜索关键词（必填）
- `--slug`：HTML 文件名（不含 .html），默认取关键词
- `--title`：页面大标题，默认为关键词

## 示例

```
/xhs-overlay 杭州清明节搭子
/xhs-overlay 杭州瑜伽,杭州普拉提 --slug hz-yoga --title 杭州瑜伽普拉提
/xhs-overlay 成都搭子 --title 成都找搭子合集
```

## 前置条件

1. CDP Proxy 必须运行（`http://localhost:3456`）
2. Chrome 已开启远程调试
3. 用户已登录小红书

检查方式：
```bash
curl -s http://localhost:3456/health
```
如果未运行：
```bash
node ~/.claude/skills/web-access/scripts/check-deps.mjs
```

## 执行步骤

### 1. 解析参数

从 `$ARGUMENTS` 中提取 keywords、slug、title。

### 2. 检查 CDP

```bash
curl -s http://localhost:3456/health
```
必须返回 `connected: true`。否则提示用户启动。

### 3. 逐个关键词采集

对每个关键词执行以下流程：

#### 3a. 打开搜索页

```bash
TARGET=$(curl -s "http://localhost:3456/new?url=$(python3 -c "import urllib.parse; print(urllib.parse.quote('https://www.xiaohongshu.com/search_result?keyword=关键词&source=web_search_result_notes', safe=''))")" | python3 -c "import sys,json; print(json.load(sys.stdin)['targetId'])")
```
等待 3 秒。

#### 3b. 获取卡片数

```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d 'document.querySelectorAll("section.note-item").length'
```

#### 3c. 逐个点击卡片采集详情+评论

对每个卡片 i（从 0 到 卡片数-1）：

**点击卡片：**
```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d "document.querySelectorAll('section.note-item')[$i]?.querySelector('a.cover')?.click(); 'ok'"
```
等待 2.5 秒。

**提取笔记详情：**
```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d '
var nid = location.pathname.match(/\/(explore|search_result)\/([a-z0-9]+)/)?.[2] || "";
var tEl = document.querySelector("#detail-title") || document.querySelector("[class*=\"detail\"] .title") || document.querySelector(".title");
var dEl = document.querySelector("#detail-desc") || document.querySelector("[class*=\"detail\"] .desc") || document.querySelector(".desc");
var aLink = document.querySelector("[class*=\"author\"] a[href*=\"/user/profile/\"]");
var aName = document.querySelector("[class*=\"author\"] .username, [class*=\"author\"] [class*=\"name\"]");
var avEl = document.querySelector("[class*=\"author\"] img, img[class*=\"avatar\"]");
var covEl = document.querySelector("[class*=\"slide\"] img, .note-image img");
JSON.stringify({
  note_id: nid, title: tEl?.textContent?.trim() || "",
  content: (dEl?.textContent?.trim() || "").slice(0, 2000),
  type: document.querySelector("video") ? "video" : "normal",
  author_id: aLink?.href?.match(/\/user\/profile\/([a-z0-9]+)/)?.[1] || "",
  author_name: (aName?.textContent?.trim() || "").replace(/\d{4}-\d{2}-\d{2}$/, "").trim(),
  author_avatar: avEl?.src || "",
  liked_count: parseInt([...document.querySelectorAll("[class*=\"like\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  collected_count: parseInt([...document.querySelectorAll("[class*=\"collect\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  comment_count: parseInt([...document.querySelectorAll("[class*=\"chat\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  share_count: parseInt([...document.querySelectorAll("[class*=\"share\"] [class*=\"count\"]")].pop()?.textContent) || 0,
  note_url: location.href, cover_url: covEl?.src || "",
  source: "cdp_browser", keyword: "关键词"
})
'
```

**提取评论：**
```bash
curl -s -X POST "http://localhost:3456/eval?target=$TARGET" -d '
var noteId = location.pathname.match(/\/(explore|search_result)\/([a-z0-9]+)/)?.[2] || "";
var items = document.querySelectorAll(".comment-item");
var comments = [];
items.forEach(function(el) {
  var id = el.id?.replace("comment-", "") || "";
  var userLink = el.querySelector("a[href*='"'"'/user/profile/'"'"']");
  var userId = userLink?.getAttribute("data-user-id") || "";
  var nameEl = el.querySelector(".name");
  var avatarEl = el.querySelector(".avatar-item");
  var contentEl = el.querySelector(".note-text");
  var likeEl = el.querySelector("[class*='"'"'like'"'"'] [class*='"'"'count'"'"']");
  if (!contentEl) return;
  comments.push({
    note_id: noteId, comment_id: id, user_id: userId,
    nickname: nameEl?.textContent?.trim() || "",
    avatar: avatarEl?.src || "",
    content: contentEl?.textContent?.trim()?.slice(0, 500) || "",
    liked_count: parseInt(likeEl?.textContent) || 0,
    sub_comment_count: 0
  });
});
JSON.stringify(comments)
'
```

**返回搜索页：**
```bash
curl -s "http://localhost:3456/back?target=$TARGET"
```
等待 1.2 秒，继续下一个卡片。

#### 3d. 关闭搜索页 tab

```bash
curl -s "http://localhost:3456/close?target=$TARGET"
```

### 4. 提交数据到服务器

```bash
# 提交笔记
curl -s -X POST -H "X-API-Key: dazi2026" -H "Content-Type: application/json" \
  -d '{"notes": [...], "keyword": "关键词"}' \
  "http://113.44.65.151:3721/api/collect/notes"

# 提交评论
curl -s -X POST -H "X-API-Key: dazi2026" -H "Content-Type: application/json" \
  -d '{"comments": [...]}' \
  "http://113.44.65.151:3721/api/collect/comments"
```

### 5. 导出 HTML

调用服务器导出接口获取 HTML：
```bash
curl -s -X POST -H "X-API-Key: dazi2026" -H "Content-Type: application/json" \
  -d '{"keyword":"关键词","title":"页面标题"}' \
  "http://113.44.65.151:3721/api/export/html"
```

将返回的 `html` 字段保存到 `/Users/wenpi/seomachine/shaihe-site/pages/{slug}.html`。

### 6. 提交并推送到 GitHub

```bash
cd /Users/wenpi/seomachine/shaihe-site
git add pages/{slug}.html
git commit -m "Add: {title}"
git pull --rebase origin main
git push origin main
```

### 7. 输出结果

输出：
- 采集统计：X 篇笔记，Y 条评论
- 本地文件路径
- GitHub Pages 访问 URL：`https://wenpi.github.io/shaihe-office/pages/{slug}.html`

## 关键技术点

- **CDP overlay 模式**：在搜索页点击卡片，小红书弹出详情 overlay（URL 变为 `/search_result/{noteId}?xsec_token=...`），从 overlay DOM 采集完整内容，`history.back()` 关闭 overlay 回到搜索列表
- **天然登录态**：CDP 直连用户日常 Chrome，无需 Cookie/签名，零风控风险
- **评论 DOM 选择器**：`.comment-item` 内含 `.name`（昵称）、`.avatar-item`（头像）、`.note-text`（内容）、`data-user-id`（用户ID）
- **笔记 DOM 选择器**：`#detail-desc .desc`（正文）、`.title`（标题）、`[class*="like"] [class*="count"]`（互动数据）

## 依赖

- CDP Proxy（web-access skill 提供，`localhost:3456`）
- Chrome 远程调试已开启
- 搭子工具服务器（`113.44.65.151:3721`）
- shaihe-site GitHub 仓库（GitHub Pages）
